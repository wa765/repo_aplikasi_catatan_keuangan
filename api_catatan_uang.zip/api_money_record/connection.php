<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "money";

$connect = new mysqli($host, $user, $password, $database);